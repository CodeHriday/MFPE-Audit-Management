package com.mfpe.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mfpe.model.AuditType;
import com.mfpe.model.AuditQuestion;

@FeignClient(url = "${ms.checklist}", name="audit-checklist")
public interface AuditCheckListFeign {
	
	@RequestMapping(value = "/AuditCheckListQuestions", method = RequestMethod.POST )
	public ResponseEntity<List<AuditQuestion>> auditCheckListQuestions(@RequestHeader("Authorization")String jwt,@RequestBody AuditType auditType);
	
}